/**********************************************************************
* Description:	This is a modification of the CCV table -- adjusted to use a
*               guid to identify a set of rows/records for the person who
*               just signed up.
* Created By:   Nick Airdo @ Central Christian Church (AZ)
* Date Created:	08/26/2013 11:46:29
*
* $Workfile: cust_ccv_core_person_datetime.sql $
* $Revision: 1 $ 
* $Header: /trunk/Database/Tables/cust/Ccv/cust_ccv_core_person_datetime.sql   1   2013-08-28 10:00:26-07:00   nicka $
* 
* $Log: /trunk/Database/Tables/cust/Ccv/cust_ccv_core_person_datetime.sql $
*  
*  Revision: 1   Date: 2013-08-28 17:00:26Z   User: nicka 
***********************************************************************/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[cust_ccv_core_person_datetime](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[person_id] [int] NOT NULL,
	[campus_id] [int] NOT NULL,
	[selected_datetime] [datetime] NOT NULL,
	[guid] [uniqueidentifier] NULL
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[cust_ccv_core_person_datetime]  WITH CHECK ADD  CONSTRAINT [FK_cust_ccv_core_person_datetime_core_person] FOREIGN KEY([person_id])
REFERENCES [dbo].[core_person] ([person_id])
GO

ALTER TABLE [dbo].[cust_ccv_core_person_datetime] CHECK CONSTRAINT [FK_cust_ccv_core_person_datetime_core_person]
GO

ALTER TABLE [dbo].[cust_ccv_core_person_datetime]  WITH CHECK ADD  CONSTRAINT [FK_cust_ccv_core_person_datetime_orgn_campus] FOREIGN KEY([campus_id])
REFERENCES [dbo].[orgn_campus] ([campus_id])
GO

ALTER TABLE [dbo].[cust_ccv_core_person_datetime] CHECK CONSTRAINT [FK_cust_ccv_core_person_datetime_orgn_campus]
GO
